import { Component, Inject, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { BehaviorSubject, Observable, from, of } from 'rxjs';
import { filter, map, switchMap, tap } from 'rxjs/operators';
import { CatalogBrowserService } from "../../services/catalog-browser.service";
import { CatalogService, ContractNegotiationDto, ContractNegotiationService, NegotiationInitiateRequestDto, TransferProcessService } from "../../../mgmt-api-client";
import { NotificationService } from "../../services/notification.service";
import { Router } from "@angular/router";
import { TransferProcessStates } from "../../models/transfer-process-states";
import { ContractOffer } from "../../models/contract-offer";
import { NegotiationResult } from "../../models/negotiation-result";
import { ContractViewerComponent } from '../contract-viewer/contract-viewer.component';
import { LoaderService } from 'src/modules/app/components/loader/loader.service';
import { environment } from 'src/environments/environment';
import { AppConfigService } from 'src/modules/app/app-config.service';

interface RunningTransferProcess {
  processId: string;
  assetId?: string;
  state: TransferProcessStates;
}

@Component({
  selector: 'edc-demo-catalog-browser',
  templateUrl: './catalog-browser.component.html',
  styleUrls: ['./catalog-browser.component.scss']
})
export class CatalogBrowserComponent implements OnInit {

  filteredContractOffers$: Observable<ContractOffer[]> = of([]);
  searchText = '';
  runningTransferProcesses: RunningTransferProcess[] = [];
  runningNegotiations: Map<string, NegotiationResult> = new Map<string, NegotiationResult>(); // contractOfferId, NegotiationResult
  finishedNegotiations: Map<string, ContractNegotiationDto> = new Map<string, ContractNegotiationDto>(); // contractOfferId, contractAgreementId
  private fetch$ = new BehaviorSubject(null);
  private pollingHandleNegotiation?: any;
  datasets?: any;
  transferAccess: boolean[] = [];
  private runningTransfers: any[] = [];
  private pollingHandleTransfer?: any;
  index: any;
  fetchAccess: boolean[] = [];
  authToken: any;
  responseData: any;
  constructor(private apiService: CatalogBrowserService,
    public dialog: MatDialog,
    private notificationService: NotificationService,
    private catalogService: CatalogService,
    private negotiationService: ContractNegotiationService,
    private transferService: TransferProcessService,
    private loaderService: LoaderService,
    private appConfigService: AppConfigService,
    @Inject('HOME_CONNECTOR_STORAGE_ACCOUNT') private homeConnectorStorageAccount: string) {
  }



  ngOnInit(): void {
    localStorage.clear();
    sessionStorage.clear();
    this.filteredContractOffers$ = this.fetch$
      .pipe(
        switchMap(() => {
          const contractOffers$ = this.apiService.getContractOffers();
          return !!this.searchText ?
            contractOffers$.pipe(map(contractOffers => contractOffers.filter(contractOffer => contractOffer.asset.name.toLowerCase().includes(this.searchText))))
            :
            contractOffers$;
        }));
    this.fetchCatalog();
  }

  fetchCatalog() {
    // let catalogObject = {
    //   "@context": {
    //     "edc": "https://w3id.org/edc/v0.0.1/ns/"
    //   },
    //   "providerUrl": "http://localhost:19194/protocol",
    //   "protocol": "dataspace-protocol-http"
    // }
    let catalogObject: any = {
      "@context": {},
      "protocol": "dataspace-protocol-http",
      "providerUrl": this.appConfigService.getConfig()?.providerUrl,
      "querySpec": {
          "offset": 0,
          "limit": 100,
          "filter": "",
          "range": {
              "from": 0,
              "to": 100
          },
          "criterion": ""
      }
  }
    this.catalogService.requestCatalog(catalogObject).subscribe((res: any) => {
      this.datasets = Array.isArray(res['dcat:dataset']) ? res['dcat:dataset'] : [res['dcat:dataset']]
      console.log(this.datasets);
    });
  }

  onSearch() {
    this.fetch$.next(null);
  }

  onNegotiateClicked(contractOffer: any, index: any) {
    this.loaderService.show();
    let policy = contractOffer['odrl:hasPolicy'];
    let offerId = Array.isArray(policy) ? policy[0]['@id'] : policy['@id']
    let request = {
      "@context": {
        "edc": "https://w3id.org/edc/v0.0.1/ns/",
        "odrl": "http://www.w3.org/ns/odrl/2/"
      },
      "@type": "NegotiationInitiateRequestDto",
      "connectorId": "AESC",
      "connectorAddress": "http://localhost:19194/protocol",
      "consumerId": "NISSAN",
      "providerId": "AESC",
      "protocol": "dataspace-protocol-http",
      "offer": {
        "offerId": offerId,
        "assetId": contractOffer['edc:id'],
        "policy": Array.isArray(policy) ? policy[0] : policy
      }
    }
    const initiateRequest: any = {
      "@context": {
        "odrl": "http://www.w3.org/ns/odrl/2/"
      },
      "@type": "NegotiationInitiateRequestDto",
      "connectorAddress": this.appConfigService.getConfig()?.providerUrl,
      "protocol": "dataspace-protocol-http",
      "connectorId": "AESC",
      "providerId": "AESC",
      "offer": {
        "offerId": "MQ==:MQ==:ZDM4Nzk3NmUtZjA0Ny00ZmNjLWFhNWItYjQwYmVkMDBhZGYy",
        "assetId": contractOffer['edc:id'],
        "policy": {
          "@type": "odrl:Set",
          "odrl:permission": {
            "odrl:target": contractOffer['edc:id'],
            "odrl:action": {
              "odrl:type": "USE"
            },
            "odrl:constraint": {
              "odrl:or": {
                "odrl:leftOperand": "BusinessPartnerNumber",
                "odrl:operator": {
                                "@id": "odrl:eq"
                            },
                "odrl:rightOperand": "BPNSOKRATES"
              }
            }
          },
          "odrl:prohibition": [],
          "odrl:obligation": [],
          "odrl:target": contractOffer['edc:id']
        }
      }
    }
    const finishedNegotiationStates = [
      "CONFIRMED",
      "FINALIZED",
      "VERIFIED",
      "DECLINED",
      "ERROR"];

    this.negotiationService.initiateContractNegotiation(initiateRequest).subscribe((negotiation: any) => {
      this.finishedNegotiations.delete(request.offer.offerId);
      this.runningNegotiations.set(request.offer.offerId, {
        id: negotiation['@id'],
        offerId: request.offer.offerId
      });
      this.storeId(negotiation['@id']);

      if (!this.pollingHandleNegotiation) {
        // there are no active negotiations
        this.pollingHandleNegotiation = setInterval(() => {
          // const finishedNegotiations: NegotiationResult[] = [];

          for (const negotiation of this.runningNegotiations.values()) {
            this.negotiationService.getNegotiationState(negotiation.id).subscribe((updatedNegotiation: any) => {
              if (finishedNegotiationStates.includes((updatedNegotiation['edc:state'])!)) {
                let offerId = negotiation.offerId;
                this.runningNegotiations.delete(offerId);
                if (updatedNegotiation['edc:state'] === "CONFIRMED" || updatedNegotiation['edc:state'] === "FINALIZED" || updatedNegotiation['edc:state'] === "VERIFIED") {
                  this.finishedNegotiations.set(offerId, updatedNegotiation);
                  this.storeId(updatedNegotiation['edc:contractAgreementId']);
                  this.transferAccess[index] = true;
                  this.notificationService.showInfo("Contract Negotiation complete!")
                  this.loaderService.hide();
                }
              }

              if (this.runningNegotiations.size === 0) {
                clearInterval(this.pollingHandleNegotiation);
                this.pollingHandleNegotiation = undefined;
              }
            });
          }
        }, 1000);
      }
    }, error => {
      console.error(error);
      this.notificationService.showError("Error starting negotiation");
      this.loaderService.hide();
    });
  }

  storeId(data: any) {
    localStorage.setItem("agreementId", JSON.stringify(data) || "");

    // if (!negotiateIds.includes(data)) {
    //   negotiateIds.push(data)
    //   localStorage.setItem("negotiateIds", JSON.stringify(negotiateIds));
    // }
  }
  isBusy(contractOffer: ContractOffer) {
    return this.runningNegotiations.get(contractOffer.id) !== undefined || !!this.runningTransferProcesses.find(tp => tp.assetId === contractOffer.asset.id);
  }

  getState(contractOffer: ContractOffer): string {
    const transferProcess = this.runningTransferProcesses.find(tp => tp.assetId === contractOffer.asset.id);
    if (transferProcess) {
      return TransferProcessStates[transferProcess.state];
    }

    const negotiation = this.runningNegotiations.get(contractOffer.id);
    if (negotiation) {
      return 'negotiating';
    }

    return '';
  }

  isNegotiated(contractOffer: ContractOffer) {
    return this.finishedNegotiations.get(contractOffer.id) !== undefined;
  }

}
