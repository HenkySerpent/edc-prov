import { Component, OnInit } from '@angular/core';
import { environment } from 'src/environments/environment';
import { DataplaneSelectorService } from 'src/modules/mgmt-api-client/api/dataplaneSelector.service';
import { NotificationService } from '../../services/notification.service';
import { CatalogService } from 'src/modules/mgmt-api-client/api/catalog.service';
import { AppConfigService } from 'src/modules/app/app-config.service';

@Component({
  selector: 'app-data-plane',
  templateUrl: './data-plane.component.html',
  styleUrls: ['./data-plane.component.scss']
})
export class DataPlaneComponent implements OnInit {

  constructor(private dataService:  DataplaneSelectorService,
    private notificationService: NotificationService,
    private catalogService: CatalogService,
    private appConfigService: AppConfigService,
    ) { }
  public type = this.appConfigService.getConfig()?.value;
  allowedSourceTypes = [ "HttpData", "AzureStorage", "Amazon S3" ];
  sourceType: any = "HttpData";

  ngOnInit() {
  }

  registerInstance () {
    let dataPlaneInstance: any;
    if(this.type === 'Provider') {
      dataPlaneInstance = {
        "edctype": "dataspaceconnector:dataplaneinstance",
        "id": "http-pull-provider-dataplane",
        "url": "http://10.203.38.215:19192/control/transfer",
        "allowedSourceTypes": [ this.sourceType ],
        "allowedDestTypes": [ "HttpProxy", "HttpData" ],
        "properties": {
          "publicApiUrl": "http://10.203.38.215:19291/public/"
        }
      }
    } else {
      dataPlaneInstance = {
        "edctype": "dataspaceconnector:dataplaneinstance",
        "id": "http-pull-consumer-dataplane",
        "url": "http://10.203.38.215:29192/control/transfer",
        "allowedSourceTypes": [ "HttpData" ],
        "allowedDestTypes": [ "HttpProxy", "HttpData" ],
        "properties": {
          "publicApiUrl": "http://10.203.38.215:29291/public/"
        }
      }
    }
    this.dataService.addEntry(dataPlaneInstance).subscribe((res) => {
      this.notificationService.showInfo(`Successfully registered ${this.appConfigService.getConfig()?.value}`)
    });

  }
  fetchCatalog () {
    let catalogObject = {
      "@context": {
          "edc": "https://w3id.org/edc/v0.0.1/ns/"
      },
      "providerUrl": "http://localhost:19194/protocol",
      "protocol": "dataspace-protocol-http"
  }
    this.catalogService.requestCatalog(catalogObject).subscribe((res) => {
      console.log(res)
    });
  }

}
