package com.backend.catenax.controller;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

import org.apache.commons.io.IOUtils;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ReceiverController {
	
	static String latestAuth = "NO_REQUEST";

    @PostMapping("/receive")
    public ResponseEntity<String> printRequest(@RequestBody String requestBody) {
        System.out.println("Received request body:");
        System.out.println(requestBody);
        ReceiverController.latestAuth = requestBody;
        return new ResponseEntity<String>(HttpStatus.OK);
    }
    
    
    @GetMapping("/emission-data")
    public ResponseEntity<String> getEmissionData() throws IOException {
    	ClassPathResource staticData = new ClassPathResource("Pcf.json");
    	String staticDataString = IOUtils.toString(staticData.getInputStream(), StandardCharsets.UTF_8);
        System.out.println("Called Emission API");
        return new ResponseEntity<String>(staticDataString, HttpStatus.OK);
    }
    
    @GetMapping("/auth")
    public ResponseEntity<String> getAuth() throws IOException {
        return new ResponseEntity<String>(ReceiverController.latestAuth, HttpStatus.OK);
    }
}