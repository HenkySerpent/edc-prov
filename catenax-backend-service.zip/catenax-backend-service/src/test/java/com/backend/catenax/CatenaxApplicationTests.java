package com.backend.catenax;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CatenaxApplicationTests {

	@Test
	void contextLoads() {
	}

}
