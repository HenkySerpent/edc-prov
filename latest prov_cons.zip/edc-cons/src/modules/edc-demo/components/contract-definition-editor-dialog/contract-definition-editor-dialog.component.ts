import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import {
  AssetService, ContractDefinitionRequestDto,
  CriterionDto, Policy, PolicyDefinitionResponseDto,
  PolicyService
} from "../../../mgmt-api-client";
import { map } from "rxjs/operators";
import { Asset } from "../../models/asset";


@Component({
  selector: 'edc-demo-contract-definition-editor-dialog',
  templateUrl: './contract-definition-editor-dialog.component.html',
  styleUrls: ['./contract-definition-editor-dialog.component.scss']
})
export class ContractDefinitionEditorDialog implements OnInit {

  policies: Array<any> = [];
  availableAssets: Asset[] = [];
  name: string = '';
  editMode = false;
  accessPolicy?: PolicyDefinitionResponseDto;
  contractPolicy?: PolicyDefinitionResponseDto;
  assets: Asset[] = [];
  contractDefinition: any = {
    '@id': '1',
    accessPolicyId: undefined!,
    contractPolicyId: undefined!
  };

  constructor(private policyService: PolicyService,
    private assetService: AssetService,
    private dialogRef: MatDialogRef<ContractDefinitionEditorDialog>,
    @Inject(MAT_DIALOG_DATA) contractDefinition?: ContractDefinitionRequestDto) {
    if (contractDefinition) {
      this.contractDefinition = contractDefinition;
      this.editMode = true;
    }
  }

  ngOnInit(): void {
    this.policyService.getAllPolicies().subscribe(policyDefinitions => {
      this.policies = policyDefinitions;
      this.accessPolicy = this.policies.find((policy: any) => policy['@id'] === this.contractDefinition.accessPolicyId);
      this.contractPolicy = this.policies.find((policy: any) => policy['@id'] === this.contractDefinition.contractPolicyId);
    });
    this.assetService.getAllAssets().pipe(map(asset => asset.map(a => new Asset(a.properties!)))).subscribe(assets => {
      this.availableAssets = assets;
      // preselection
      if (this.contractDefinition) {
        const assetIds = this.contractDefinition.criteria.map((c: CriterionDto) => c.operandRight?.toString());
        this.assets = this.availableAssets.filter(asset => assetIds.includes(asset.id));
      }
    })
  }

  onSave() {
    // this.contractDefinition.accessPolicyId = this.accessPolicy;
    // this.contractDefinition.contractPolicyId = this.contractPolicy;
    // this.contractDefinition['@context'] = {
    //   "edc": "https://w3id.org/edc/v0.0.1/ns/"
    // };
    // this.contractDefinition['@id'] = this.contractDefinition.id
    this.dialogRef.close({
      "contractDefinition": {
        "@context": {},
        "@id": this.contractDefinition.id,
        "@type": "ContractDefinition",
        "accessPolicyId": this.accessPolicy,
        "contractPolicyId": this.contractPolicy,
        "assetsSelector": {
          "@type": "CriterionDto",
          "operandLeft": "https://w3id.org/edc/v0.0.1/ns/id",
          "operator": "=",
          "operandRight": this.assets
        }
      }
    });
  }
}
