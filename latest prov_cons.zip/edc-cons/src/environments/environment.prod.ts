export const environment = {
  production: true,
  apiKey: "password",
  providerUrl: "http://10.203.38.215:19194/protocol",
  managementUrl: "http://10.203.38.215:29193/management",
  publicUrl: "http://10.203.38.215:29291",
  authUrl: "http://10.203.38.215:4000",
  dataManagementApiUrl: "http://localhost:9192/api/v1/data",
  catalogUrl: "http://localhost:9191/api/v1/data",
  storageAccount: "company2assets",
  storageExplorerLinkTemplate: "storageexplorer://v=1",
  theme: "theme-2",
  value: "NISSAN",
};

