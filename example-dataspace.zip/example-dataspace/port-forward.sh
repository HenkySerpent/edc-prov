#!/bin/bash

kubectl port-forward tx-plato-dataplane-7c87b87f6d-vj2bb 16161:8081