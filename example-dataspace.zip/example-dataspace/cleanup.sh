#!/bin/bash

# Delete all resources in the "default" namespace
#kubectl delete all --all -n default

# Delete the Helm releases
helm delete tx-sokrates
helm delete tx-plato

kubectl -n kubernetes-dashboard create token admin-user