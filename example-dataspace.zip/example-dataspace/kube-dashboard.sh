#!/bin/bash
kubectl -n kubernetes-dashboard create token admin-user
#nohup kubectl proxy --port=4919 &
