#!/bin/bash

kind load docker-image edc-controlplane-postgresql-hashicorp-vault
kind load docker-image edc-dataplane-hashicorp-vault
