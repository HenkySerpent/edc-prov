#!/bin/bash

echo "aes_enckey_test" | base64 > sokrates.aes.key

# PLATO aes encryption key
echo "aes_enckey_test" | base64 > plato.aes.key

VALUES_FILE=sokrates-values.yaml
CLIENT_SECRET=PQ1ojcp7QlJ323CkrUFlLW8HS0dx2wlN
AES_KEY=$(cat sokrates.aes.key)
yq -i ".vault.server.postStart |= [\"sh\",\"-c\",\"{\nsleep 5\n
/bin/vault kv put secret/client-secret content=$CLIENT_SECRET\n
/bin/vault kv put secret/aes-keys content=$AES_KEY\n}\"]" "$VALUES_FILE"

# for plato
VALUES_FILE=plato-values.yaml
CLIENT_SECRET=gLnivEHydQ4K2hd5browOU2KrfVFAUfK
AES_KEY=$(cat plato.aes.key)
yq -i ".vault.server.postStart |= [\"sh\",\"-c\",\"{\nsleep 5\n
/bin/vault kv put secret/client-secret content=$CLIENT_SECRET\n
/bin/vault kv put secret/aes-keys content=$AES_KEY\n}\"]" "$VALUES_FILE"
helm delete tx-plato
helm delete tx-sokrates
helm install tx-sokrates tractusx-edc/tractusx-connector \
     -f sokrates-values.yaml \
     --dependency-update

helm install tx-plato tractusx-edc/tractusx-connector \
     -f plato-values.yaml \
     --dependency-update

#helm upgrade tx-sokrates tractusx-edc/tractusx-connector \
#     -f sokrates-values.yaml \
#     --dependency-update
#
#helm upgrade tx-plato tractusx-edc/tractusx-connector \
#     -f plato-values.yaml \
#     --dependency-update