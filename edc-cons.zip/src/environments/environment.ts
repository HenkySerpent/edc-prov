// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
export const environment = {
  production: false,
  apiKey: "password",
  providerUrl: "http://10.203.38.215:19194/protocol",
  managementUrl: "http://10.203.38.215:29193/management",
  publicUrl: "http://10.203.38.215:29291",
  authUrl: "http://10.203.38.215:4000",
  dataManagementApiUrl: "http://localhost:9192/api/v1/data",
  catalogUrl: "http://localhost:9191/api/v1/data",
  storageAccount: "company2assets",
  storageExplorerLinkTemplate: "storageexplorer://v=1",
  theme: "theme-2",
  value: "NISSAN",
};


/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
