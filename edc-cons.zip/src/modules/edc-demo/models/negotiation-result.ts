export interface NegotiationResult {
    id: string;
    offerId: string;
}
