import { Component, Inject, OnInit } from '@angular/core';
import { Policy, PolicyDefinitionResponseDto, PolicyDefinitionRequestDto } from "../../../mgmt-api-client";
import TypeEnum = Policy.TypeEnum;
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material/dialog";

@Component({
  selector: 'app-new-policy-dialog',
  templateUrl: './new-policy-dialog.component.html',
  styleUrls: ['./new-policy-dialog.component.scss']
})
export class NewPolicyDialogComponent implements OnInit {
  editMode: boolean = false;
  policy: any = {};
  policyDefinition: PolicyDefinitionResponseDto = {
    policy: this.policy,
    id: ''
  };
  permissionsJson: string = '';
  prohibitionsJson: string = '';
  obligationsJson: string = '';

  constructor(private dialogRef: MatDialogRef<NewPolicyDialogComponent>) {
  }

  ngOnInit(): void {
    this.editMode = true;
  }

  onSave() {
    this.policy.type = 'SET';
    if (this.permissionsJson && this.permissionsJson !== '') {
      this.policy['odrl:permissions'] = JSON.parse(this.permissionsJson);
    }

    if (this.prohibitionsJson && this.prohibitionsJson !== '') {
      this.policy["odrl:prohibition"] = JSON.parse(this.prohibitionsJson);
    }

    if (this.obligationsJson && this.obligationsJson !== '') {
      this.policy['odrl:obligation'] = JSON.parse(this.obligationsJson);
    }

    this.dialogRef.close(    {
      "@context": {
          "odrl": "http://www.w3.org/ns/odrl/2/"
      },
      "@type": "PolicyDefinitionRequestDto",
      "@id": this.policyDefinition.id,
      "policy": {
      "@type": "Policy",
      "odrl:permission" : [{
        "odrl:action" : "USE",
        "odrl:constraint" : {
          "@type": "LogicalConstraint",
          "odrl:or" : [{
            "@type" : "Constraint",
            "odrl:leftOperand" : "BusinessPartnerNumber",
            "odrl:operator" : {
                          "@id": "odrl:eq"
                      },
            // "odrl:rightOperand" : "{{POLICY_BPN}}"
            "odrl:rightOperand" : "BPNSOKRATES"

          }]
        }
      }]
      }
  })
  }
}

// '@context': {
//   "edc": "https://w3id.org/edc/v0.0.1/ns/",
//   "odrl": "http://www.w3.org/ns/odrl/2/"
// },
// 'policy':  {
//   "@type": "set",
//   "odrl:permission": [],
//   "odrl:prohibition": [],
//   "odrl:obligation": []
// },
// '@id': this.policyDefinition.id
